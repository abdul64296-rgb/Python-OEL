"""app.py: the GUI only. All data and quiz rules live in logic.py."""
import tkinter as tk
from tkinter import messagebox
import logic

# ---------- Theme (works like a CSS file: change a colour here and it changes everywhere) ----------
BG, PANEL, HOVER = "#14151f", "#1f2133", "#34375a"
Q_FACE, A_FACE, SHADOW = "#2b2e4d", "#16403f", "#0d0e16"
TEXT, MUTED = "#f4f4fa", "#8d91ad"
ACCENT, ACCENT_HOVER, ACCENT2 = "#7c6cff", "#9488ff", "#4fd1c5"
GOOD, BAD = "#34d399", "#f87171"
FONT = "Segoe UI"
CARD_W, CARD_H = 480, 270


# ---------- Small drawing helpers (the "components") ----------
def round_rect(c, x1, y1, x2, y2, r, **kw):
    # A polygon with smooth=True turns the corner points into rounded corners
    pts = [x1 + r, y1, x2 - r, y1, x2, y1, x2, y1 + r, x2, y2 - r, x2, y2,
           x2 - r, y2, x1 + r, y2, x1, y2, x1, y2 - r, x1, y1 + r, x1, y1]
    return c.create_polygon(pts, smooth=True, **kw)


def gradient(parent, w, h, c1, c2):
    # Draw one thin vertical line per pixel, each slightly closer to the second colour
    c = tk.Canvas(parent, width=w, height=h, highlightthickness=0, bd=0)
    a = [int(c1[i:i + 2], 16) for i in (1, 3, 5)]
    b = [int(c2[i:i + 2], 16) for i in (1, 3, 5)]
    for x in range(w):
        mix = [int(a[k] + (b[k] - a[k]) * x / w) for k in range(3)]
        c.create_line(x, 0, x, h, fill="#%02x%02x%02x" % tuple(mix))
    return c


def button(parent, text, command, color=ACCENT, hover=ACCENT_HOVER, width=150, height=44, bg=BG):
    # Normal tk buttons cannot have rounded corners, so we draw our own on a Canvas
    c = tk.Canvas(parent, width=width, height=height, bg=bg, highlightthickness=0, cursor="hand2")
    c.shape = round_rect(c, 1, 1, width - 1, height - 1, 14, fill=color, outline="")
    c.create_text(width / 2, height / 2, text=text, fill="white", font=(FONT, 11, "bold"))
    c.text, c.color, c.hover, c.locked = text, color, hover, False
    c.bind("<Enter>", lambda e: not c.locked and c.itemconfig(c.shape, fill=c.hover))
    c.bind("<Leave>", lambda e: not c.locked and c.itemconfig(c.shape, fill=c.color))
    c.bind("<Button-1>", lambda e: not c.locked and command())
    return c


def paint(btn, color):
    btn.color = color  # remember it so the hover effect restores the right colour
    btn.itemconfig(btn.shape, fill=color)


def progress_bar(parent):
    c = tk.Canvas(parent, width=CARD_W, height=8, bg=BG, highlightthickness=0)
    round_rect(c, 0, 0, CARD_W, 8, 4, fill=PANEL, outline="")

    def set_value(fraction):  # 0.0 = empty, 1.0 = full
        c.delete("fill")
        round_rect(c, 0, 0, max(CARD_W * fraction, 8), 8, 4, fill=ACCENT, outline="", tags="fill")

    c.set = set_value
    return c


def clear():
    for key in ("<space>", "<Left>", "<Right>", "<Return>"):
        root.unbind(key)  # remove the keyboard shortcuts of the old screen
    for w in body.winfo_children():
        w.destroy()  # remove the old screen before drawing a new one


def set_tab(name):
    for n, b in tabs.items():  # the active tab gets the accent colour
        b.hover = ACCENT_HOVER if n == name else HOVER
        paint(b, ACCENT if n == name else PANEL)


# ---------- Study mode ----------
def study_mode():
    clear()
    set_tab("Study")
    state = {"i": 0, "show": False, "busy": False}  # card number, answer visible?, animating?
    bar = progress_bar(body)
    bar.pack(pady=(14, 14))
    card = tk.Canvas(body, width=CARD_W, height=CARD_H + 10, bg=BG, highlightthickness=0, cursor="hand2")
    card.pack()
    count = tk.Label(body, bg=BG, fg=MUTED, font=(FONT, 10, "bold"))
    count.pack(pady=10)

    def draw(scale=1):
        c = cards[state["i"]]
        w = CARD_W * scale  # scale below 1 makes the card thinner (used by the flip animation)
        x1 = (CARD_W - w) / 2
        face, tag_color = (A_FACE, ACCENT2) if state["show"] else (Q_FACE, ACCENT)
        card.delete("all")
        round_rect(card, x1, 10, CARD_W - x1, CARD_H + 10, min(26, w / 2), fill=SHADOW, outline="")
        round_rect(card, x1, 0, CARD_W - x1, CARD_H, min(26, w / 2), fill=face, outline="")
        if scale == 1:
            card.create_text(CARD_W / 2, 38, fill=tag_color, font=(FONT, 10, "bold"),
                             text="ANSWER" if state["show"] else "QUESTION")
            # Dictionary lookup: "a" holds the answer, "q" holds the question
            card.create_text(CARD_W / 2, CARD_H / 2 + 10, text=c["a"] if state["show"] else c["q"],
                             fill=TEXT, font=(FONT, 20, "bold"), width=CARD_W - 70, justify="center")

    def refresh():
        draw()
        count.config(text=f"CARD {state['i'] + 1} OF {len(cards)}")
        bar.set((state["i"] + 1) / len(cards))

    def flip():
        if state["busy"]:
            return
        state["busy"] = True

        # Animation: shrink the card, swap question and answer (None) when thin, grow it back
        def run(frames):
            if not card.winfo_exists():
                return  # the user switched tabs during the animation
            if not frames:
                state["busy"] = False
                return
            if frames[0] is None:
                state["show"] = not state["show"]
            else:
                draw(frames[0])
            root.after(18, run, frames[1:])  # draw the next frame after 18 ms

        run([0.8, 0.6, 0.4, 0.2, 0.05, None, 0.2, 0.4, 0.6, 0.8, 1])

    def move(step):
        if state["busy"]:
            return
        state["i"] = (state["i"] + step) % len(cards)  # % wraps around at both ends
        state["show"] = False
        refresh()

    card.bind("<Button-1>", lambda e: flip())
    root.bind("<space>", lambda e: flip())  # keyboard shortcuts
    root.bind("<Left>", lambda e: move(-1))
    root.bind("<Right>", lambda e: move(1))
    row = tk.Frame(body, bg=BG)
    row.pack()
    button(row, "<  Prev", lambda: move(-1), PANEL, HOVER, 120).pack(side="left", padx=6)
    button(row, "Flip Card", flip, width=160).pack(side="left", padx=6)
    button(row, "Next  >", lambda: move(1), PANEL, HOVER, 120).pack(side="left", padx=6)
    tk.Label(body, text="Tip: click the card or press Space to flip", bg=BG, fg=MUTED,
             font=(FONT, 9)).pack(pady=12)
    refresh()


# ---------- Quiz mode ----------
def quiz_mode():
    clear()
    set_tab("Quiz")
    order = logic.new_quiz(cards)
    state = {"i": 0, "score": 0}
    bar = progress_bar(body)
    bar.pack(pady=(14, 10))
    info = tk.Frame(body, bg=BG)
    info.pack(fill="x", padx=40)
    step_label = tk.Label(info, bg=BG, fg=MUTED, font=(FONT, 10, "bold"))
    step_label.pack(side="left")
    score_label = tk.Label(info, bg=BG, fg=ACCENT2, font=(FONT, 10, "bold"))
    score_label.pack(side="right")
    qbox = tk.Canvas(body, width=CARD_W, height=140, bg=BG, highlightthickness=0)
    qbox.pack(pady=12)
    round_rect(qbox, 0, 0, CARD_W, 130, 24, fill=Q_FACE, outline="")
    qtext = qbox.create_text(CARD_W / 2, 65, fill=TEXT, font=(FONT, 16, "bold"),
                             width=CARD_W - 60, justify="center")
    options = tk.Frame(body, bg=BG)
    options.pack()

    def show_question():
        for w in options.winfo_children():
            w.destroy()  # remove the previous answer buttons
        card = order[state["i"]]
        step_label.config(text=f"QUESTION {state['i'] + 1} OF {len(order)}")
        score_label.config(text=f"Score: {state['score']}")
        qbox.itemconfig(qtext, text=card["q"])
        bar.set(state["i"] / len(order))
        for choice in logic.quiz_options(cards, card):
            # ch=choice stores this button's own answer (otherwise every button would use the last one)
            button(options, choice, lambda ch=choice: answer(ch), PANEL, HOVER, CARD_W, 48).pack(pady=5)

    def answer(choice):
        right = order[state["i"]]["a"]
        for b in options.winfo_children():
            b.locked = True  # stop extra clicks
            if b.text == right:
                paint(b, GOOD)  # the correct answer turns green
            elif b.text == choice:
                paint(b, BAD)  # a wrong pick turns red
        if choice == right:
            state["score"] += 1
        state["i"] += 1
        root.after(900, next_question)  # short pause so the colours can be seen

    def next_question():
        if not options.winfo_exists():
            return  # the user switched tabs during the pause
        if state["i"] < len(order):
            show_question()
        else:
            bar.set(1)
            messagebox.showinfo("Quiz Finished", logic.result_message(state["score"], len(order)))
            study_mode()

    show_question()


# ---------- Add card mode ----------
def add_mode():
    clear()
    set_tab("Add Card")
    box = tk.Frame(body, bg=PANEL, padx=24, pady=16)
    box.pack(fill="x", padx=40, pady=18)
    entries = []
    for label in ("QUESTION", "ANSWER"):
        tk.Label(box, text=label, bg=PANEL, fg=MUTED, font=(FONT, 10, "bold")).pack(anchor="w", pady=(12, 4))
        e = tk.Entry(box, bg=BG, fg=TEXT, insertbackground=TEXT, relief="flat", font=(FONT, 12),
                     highlightthickness=2, highlightbackground=HOVER, highlightcolor=ACCENT)
        e.pack(fill="x", ipady=8)  # the border turns purple while you type
        entries.append(e)
    status = tk.Label(box, bg=PANEL, font=(FONT, 10, "bold"))
    status.pack(pady=(14, 8))

    def add():
        q, a = (e.get() for e in entries)  # read both text boxes
        if logic.add_card(cards, q, a):  # logic.py adds the card and saves cards.json
            for e in entries:
                e.delete(0, tk.END)  # clear the boxes for the next card
            entries[0].focus()
            status.config(text=f"Card saved! You now have {len(cards)} cards.", fg=GOOD)
        else:
            status.config(text="Please fill in both boxes.", fg=BAD)

    button(box, "Save Card", add, width=432, bg=PANEL).pack()
    root.bind("<Return>", lambda e: add())  # Enter key also saves
    entries[0].focus()


# ---------- Main window ----------
cards = logic.load_cards()
root = tk.Tk()
root.title("Flashcard Studio")
root.geometry("560x680")
root.resizable(False, False)
root.configure(bg=BG)

header = gradient(root, 560, 100, ACCENT, ACCENT2)
header.pack()
header.create_text(30, 40, text="Flashcard Studio", anchor="w", fill="white", font=(FONT, 24, "bold"))
header.create_text(30, 72, text="Learn Python, one card at a time", anchor="w", fill="#eafaf8", font=(FONT, 11))

menu = tk.Frame(root, bg=BG)  # row of tab buttons
menu.pack(pady=16)
tabs = {}
for name, fn in (("Study", study_mode), ("Quiz", quiz_mode), ("Add Card", add_mode)):
    tabs[name] = button(menu, name, fn, PANEL, HOVER, 150, 42)
    tabs[name].pack(side="left", padx=5)

body = tk.Frame(root, bg=BG)  # holds whichever screen is active
body.pack(fill="both", expand=True)
study_mode()
root.mainloop()
