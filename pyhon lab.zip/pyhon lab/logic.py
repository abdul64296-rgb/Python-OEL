"""logic.py: data and quiz rules only. No tkinter in this file, so it is easy to test."""
import json, os, random

# Save cards.json next to this file, no matter which folder the program is started from
FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "cards.json")

# Built-in cards so the app works with no JSON file
DEFAULT_CARDS = [
    {"q": "Which keyword defines a function in Python?", "a": "def"},
    {"q": "Which function prints text to the screen?", "a": "print()"},
    {"q": "Which data type stores True or False?", "a": "bool"},
    {"q": "Which symbol starts a single-line comment?", "a": "#"},
    {"q": "Which function returns the length of a list?", "a": "len()"},
]


def load_cards():
    # Use the saved file if it exists, otherwise fall back to the defaults
    if os.path.exists(FILE):
        try:
            with open(FILE) as f:
                return json.load(f)
        except json.JSONDecodeError:
            pass  # broken file, use the defaults instead
    return list(DEFAULT_CARDS)


def save_cards(cards):
    with open(FILE, "w") as f:  # write the whole list to cards.json
        json.dump(cards, f, indent=2)


def add_card(cards, question, answer):
    # Returns False if a box was empty, True once the card is added and saved
    question, answer = question.strip(), answer.strip()
    if not question or not answer:
        return False
    cards.append({"q": question, "a": answer})  # each card is a small dictionary
    save_cards(cards)
    return True


def new_quiz(cards):
    return random.sample(cards, len(cards))  # a shuffled copy, the original stays in order


def quiz_options(cards, card):
    # Up to 3 wrong answers taken from the other cards, plus the right one, shuffled
    wrong = list({c["a"] for c in cards if c["a"] != card["a"]})
    options = random.sample(wrong, min(3, len(wrong))) + [card["a"]]
    random.shuffle(options)
    return options


def result_message(score, total):
    percent = round(score / total * 100)
    if percent == 100:
        verdict = "Perfect score!"
    elif percent >= 60:
        verdict = "Nice work!"
    else:
        verdict = "Keep practicing, you will get there."
    return f"You scored {score} out of {total} ({percent}%).\n{verdict}"
